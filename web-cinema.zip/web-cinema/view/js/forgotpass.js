function goToLogin() {
    window.location.href = "login-gui.php";
}