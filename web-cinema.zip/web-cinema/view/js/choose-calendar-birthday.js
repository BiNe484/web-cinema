
flatpickr('.dateofbirthtextbox', {
    
    dateFormat: 'd/m/Y',
    maxDate: 'today',
    locale: 'vi',

});
